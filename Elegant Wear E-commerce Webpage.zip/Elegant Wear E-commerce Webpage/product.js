// Array of products
const products = [
    {
      id: 1,
      name: "Red Shoulder Straps Bodycon Maxi Dress",
      price: "$49.99",
      images: ["p1.png", "p1-2.png", "p1-3.png"],
      description: "Elegant red bodycon dress with shoulder straps, perfect for evening wear.",
    },
    {
      id: 2,
      name: "Women Shoulder Straps Maxi Dress",
      price: "$59.99",
      images: ["p2.png", "p2-2.png", "p2-3.png"],
      description: "Beautiful women’s maxi dress with shoulder straps, great for casual events.",
    },
    {
      id: 3,
      name: "Motifs Embroidered Chikankari Georgette Naira Cut Kurta",
      price: "$69.99",
      images: ["p3.png", "p3-2.png", "p3-3.png"],
      description: "Elegant chikankari kurta with Naira cut and intricate motifs embroidery.",
    },
    {
      id: 4,
      name: "Ethnic Motifs Embroidered Thread Work Georgette Anarkali Kurta",
      price: "$79.99",
      images: ["p4.png", "p4-2.png", "p4-3.png"],
      description: "Stylish Anarkali kurta with ethnic motifs embroidered thread work.",
    },
    {
      id: 5,
      name: "Women Maroon Floral Printed Kurta",
      price: "$89.99",
      images: ["p5.png", "p5-2.png", "p5-3.png"],
      description: "Maroon floral printed kurta, perfect for everyday or festive wear.",
    },
    {
      id: 6,
      name: "Elegant Wear Women Black Floral Printed Maxi Dress",
      price: "$99.99",
      images: ["p6.png", "p6-2.png", "p6-3.png"],
      description: "Black floral printed maxi dress, elegant and comfortable for any event.",
    }
  ];
  
  // Function to get query parameter from URL
  function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
  }
  
  // Display product details based on product id
  function displayProduct(productId) {
    const product = products.find(p => p.id === parseInt(productId));
  
    if (product) {
      document.querySelector('.product-name').innerText = product.name;
      document.querySelector('.product-price').innerText = product.price;
      document.querySelector('.product-description').innerText = product.description;
  
      // Display product images
      const imageContainer = document.querySelector('.product-images');
      imageContainer.innerHTML = ''; // Clear previous images
      product.images.forEach(imageSrc => {
        const imgElement = document.createElement('img');
        imgElement.src = imageSrc;
        imgElement.alt = product.name;
        imageContainer.appendChild(imgElement);
      });
    }
  }
  
  // Get product id from URL and display the product
  const productId = getQueryParam('id');
  if (productId) {
    displayProduct(productId);
  }
  